package plane1;

import java.awt.image.BufferedImage;

public class EnergyTool extends ToolObject{
	protected BufferedImage image;
	public BufferedImage getImage() {
		return image;
	}

	public void setImage(BufferedImage image) {
		this.image = image;
	}
	public void move() {
		
	}
}
