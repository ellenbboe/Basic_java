package plane1;

import java.awt.image.BufferedImage;

public class LifeTool extends ToolObject {
	private BufferedImage image ;
	public LifeTool() {
		
	}
	public void move() {
		
	}
}
